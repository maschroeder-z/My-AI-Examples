---
name: fill-leave-request-form
description: >-
  Create a completed PDF leave-request form from a full name, department, first
  day off, last day off, state, manager and duration. Use when asked to fill or generate the
  bundled leave request PDF and return the completed PDF file.
---

# Fill leave request form

Always run the bundled PDF-generation script. Do not merely describe the process. On success, return the generated PDF file as the only deliverable.

## Bundled resources

- `assets/leave_request_form.pdf`: the fillable template; never overwrite it.
- `scripts/fill_leave_request.py`: the only authorized PDF generator and verifier.

## Single-artifact invariant

Generate exactly one completed PDF. The file returned by the bundled script is the
immutable `leave-request-form` artifact and is the only PDF that may be attached,
uploaded, or otherwise delivered.

- Choose the final deterministic output path before running the script and retain
  that exact path for the entire request.
- Never create an upload copy, optimized copy, flattened copy, preview PDF, or
  fallback PDF.
- Never modify the output after the script reports success. In particular, do not
  rewrite it with pypdf, ReportLab, Ghostscript, qpdf, or another PDF library.
- On an explicit retry, run the bundled script against the same output path with
  `--overwrite`. Do not choose a new filename or timestamp.
- If a downstream system cannot consume the exact returned file as binary, stop
  and report the integration error. Never regenerate a smaller PDF to work around
  transport or context-length limits.

## Required inputs

Obtain all seven values before execution:

1. Full name
2. Department
3. First day off
4. Last day off
5. Duration
6. State (Bundesland)
7. Manager (E-Mail)

Do not infer a missing value. Ask for it. Preserve the user's name, department, and duration after trimming surrounding whitespace. Normalize unambiguous dates to `YYYY-MM-DD`; ask about ambiguous dates. The last day must be on or after the first day.

## PDF field mapping

| Input | PDF field |
|---|---|
| Full name | `Name` |
| Department | `Department` |
| First day off | `FirstDay` |
| Last day off | `LastDay` |
| Duration | `Duration` |
| State | `State` |
| Manager | `Manager` |

## Executable workflow

1. Select a writable output path ending in `.pdf` outside the skill directory.
2. Run `scripts/fill_leave_request.py` from this skill's root directory in the skill script execution environment.
3. Supply all eight required options: `--name`, `--department`, `--first-day`, `--last-day`, `--duration`, `--state`, `--manager`, and `--output`.
4. When the PDF will be uploaded through a connector, always add `--include-content-base64`. This produces a verified, connector-safe payload and prevents a local path from being uploaded as text.
5. Use arguments equivalent to the following, replacing every sample value with the real value:

```text
scripts/fill_leave_request.py --name "Erika Mustermann" --department "Product Development" --first-day "2026-09-14" --last-day "2026-09-18" --duration "5" --state "Hessen" --manager "max@muster.com" --output "/writable/output/leave-request-erika-mustermann.pdf" --include-content-base64
```

The script is non-interactive and supports `--help`. It locates `assets/leave_request_form.pdf` relative to itself, creates the output directory when needed, writes a new PDF, and verifies all seven saved field values. A first attempt fails if the output already exists. An explicit retry must reuse the same path and add `--overwrite`.

On success, the script prints one JSON object with this contract:

```json
{
  "status": "success",
  "output": "/absolute/path/to/the-single-generated.pdf",
  "filename": "leave-request-erika-mustermann.pdf",
  "media_type": "application/pdf",
  "size_bytes": 0,
  "sha256": "lowercase SHA-256 digest",
  "content_encoding": "base64",
  "content_base64": "verified Base64 PDF payload"
}
```

`content_encoding` and `content_base64` are present only when `--include-content-base64` is supplied. `size_bytes` and `sha256` identify the exact immutable artifact. A nonzero exit status is an error; report stderr and do not return or upload a partial PDF.

## Binary handoff to SharePoint or another destination

A local path such as `/app/created/request.pdf` is valid only inside the skill runtime. **Never pass `output` as the upload action's file-content/body value.** In trigger-based executions, doing so uploads the pathname characters as a tiny invalid PDF.

1. For any connector upload, run the script with `--include-content-base64`.
2. Use `filename` as the destination filename.
3. Use `content_base64` as the upload action's binary file-content/body input. The action's parameter must be typed as binary (`format: binary`) so the connector decodes the Base64 to bytes. Do not prepend a data-URL prefix.
4. Perform the upload from the agent. The calling workflow does not need to read or transform the PDF.
5. Never use `output`, a shell path, JSON text, or the complete script result as file content.
6. Upload exactly once. For an explicit retry, enable overwrite and reuse the same destination path.
7. Verify that the uploaded byte size equals `size_bytes`; when supported, also verify that its SHA-256 equals `sha256`. Reject and remove an upload whose size equals the path-string length or whose first decoded bytes are not `%PDF-`.
8. Do not expose `content_base64` in the final conversational response or logs. It is a transport value for the trusted connector only.
9. If the upload action treats `content_base64` as ordinary text instead of a binary-formatted parameter, halt and report that the action schema must be corrected. Do not fall back to the local path.

## Response

When execution succeeds:

1. Read `output`, `filename`, `size_bytes`, and `sha256` from the JSON result. For connector uploads, also read `content_base64`.
2. Confirm that the exact output file exists and still matches both integrity values.
3. For a connector upload, pass only `content_base64` to the binary file-content/body parameter and verify the uploaded size.
4. Otherwise, attach the exact PDF artifact from `output`.
5. Never display or return `content_base64`, the template, the JSON result, a second PDF, or any other file.
